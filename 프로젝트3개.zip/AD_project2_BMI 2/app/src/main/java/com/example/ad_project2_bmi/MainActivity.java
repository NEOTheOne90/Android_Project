package com.example.ad_project2_bmi;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Gallery;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.nio.channels.GatheringByteChannel;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    String gender= "남자";
    String bloods= "A";
    Double bmi= 0.0;
    Double wt= 0.0;
    Double ht= 0.0;

    EditText height1, weight1;
    RadioButton radioF,  radioM;
    Spinner BTspinner;
    CheckBox alcohol, cigar, ww;
    Button RButton;
    TextView BTresult, BMIresult;
    Gallery gal;
    View dial;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("BMI 측정");


        final EditText height1 = (EditText) findViewById(R.id.height1);
        final EditText weight1 = (EditText) findViewById(R.id.weight1);

        final RadioButton radioF = (RadioButton) findViewById(R.id.radioF);
        final RadioButton radioM = (RadioButton) findViewById(R.id.radioM);

        final CheckBox alcohol = (CheckBox) findViewById(R.id.alcohol);
        final CheckBox cigar = (CheckBox) findViewById(R.id.cigar);
        final CheckBox ww = (CheckBox) findViewById(R.id.ww);

        final Button RButton = (Button) findViewById(R.id.RButton);

        final TextView BTresult = (TextView) findViewById(R.id.BTresult);
        final TextView BMIresult = (TextView) findViewById(R.id.BMIresult);

        final Gallery gal = (Gallery) findViewById(R.id.gal);
        ArrayList<Integer> cImage= new ArrayList<Integer>();


        radioM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton radioM = (RadioButton) v;
                gender = radioM.getText().toString();
            }
        });
        radioF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RadioButton radioF = (RadioButton) v;
                gender = radioF.getText().toString();
            }
        });

        final Spinner BTspinner= findViewById(R.id.BTspinner);
        final String[] blood= {"A","B","C","O","AB"};
        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this,
                android.R.layout.simple_list_item_1, blood);
        BTspinner.setAdapter(adapter);

        BTspinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                bloods = parent.getItemAtPosition(position).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        RButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ArrayList<Integer> thums = new ArrayList<Integer>();

                if(height1.getText().toString().equals("") || weight1.getText().toString().equals("")){
                    BMIresult.setText("2. 신체질량지수는 ???입니다!");

                    new AlertDialog.Builder(MainActivity.this)
                            .setTitle("키와 체중")
                            .setView(getLayoutInflater().inflate(R.layout.error_dialog, null))
                            .show();

                }
                else{
                    String str1 = height1.getText().toString();
                    String str2 = weight1.getText().toString();

                    double ht = Double.parseDouble(str1);
                    double wt = Double.parseDouble(str2);
                    double bmi = wt/ ((ht/100) * (ht/100));

                    BMIresult.setText("2신체질량지수는" + Math.round(bmi*10)/10F+"입니다!");


                }
                if (bloods.equals("") || gender.equals("")){
                    BTresult.setText("1.??형 ???입니다!");
                    return;
                }
                else{
                    BTresult.setText("1. "+bloods+"형"+gender+"입니다!");
                }
                if(alcohol.isChecked()){
                    thums.add(R.drawable.drinking);
                }
                if(cigar.isChecked()){
                    thums.add(R.drawable.ciga);
                }
                if(!ww.isChecked()){
                    thums.add(R.drawable.running);
                }
                if(alcohol.isChecked() || cigar.isChecked() || !ww.isChecked()){
                    gal.setAdapter(new ImageAdapter(MainActivity.this, thums));
                }
                else{
                    gal.removeAllViewsInLayout();
                }

            }
        });


        radioM.setChecked(true);
    }
}